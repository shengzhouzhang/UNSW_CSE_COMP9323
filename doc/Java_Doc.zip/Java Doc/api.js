YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "Auth",
        "Branch",
        "Comments",
        "Login",
        "MessageBox",
        "Progressbar",
        "RestUrl",
        "Sidebar",
        "Tabs",
        "Theme",
        "Tooltips",
        "repo",
        "taskManager"
    ],
    "modules": [],
    "allModules": []
} };
});